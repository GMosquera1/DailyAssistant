//
//  WeatherDetailsViewController.swift
//  DailyAssistant
//
//  Created by Genesis Mosquera on 3/5/19.
//  Copyright © 2019 Genesis Mosquera. All rights reserved.
//

import UIKit

class WeatherDetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    


}
