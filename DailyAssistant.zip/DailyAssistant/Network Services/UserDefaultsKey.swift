//
//  UserDefaultsKey.swift
//  DailyAssistant
//
//  Created by Genesis Mosquera on 2/26/19.
//  Copyright © 2019 Genesis Mosquera. All rights reserved.
//

import Foundation

struct UserDefaultsKey {
    static let searchTerm = "Search Term"
}
