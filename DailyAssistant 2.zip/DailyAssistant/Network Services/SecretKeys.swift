//
//  SecretKeys.swift
//  DailyAssistant
//
//  Created by Genesis Mosquera on 2/7/19.
//  Copyright © 2019 Genesis Mosquera. All rights reserved.
//

import Foundation

struct SecretKeys {
    static let APIKey = "viRDyFkwtPL4zcKRRfmr54sK5h29CbmpA6OTXPoD"
    static let clientID = "xTMfdRMckWUKeofgu9X3t"
}
