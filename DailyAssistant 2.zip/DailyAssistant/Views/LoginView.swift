//
//  LoginView.swift
//  DailyAssistant
//
//  Created by Genesis Mosquera on 3/8/19.
//  Copyright © 2019 Genesis Mosquera. All rights reserved.
//

import UIKit

enum AccountLoginState {
    case newAccount
    case existingAccount
}

protocol LoginViewDelegate: AnyObject {
    func didSelectLoginButton(_ loginView: LoginView, accountLoginState: AccountLoginState)
}

class LoginView: UIView {
    
//    @IBOutlet var contentView: UIView!
//    @IBOutlet weak var emailTextField: UITextField!
//    @IBOutlet weak var passwordTextFiled: UITextField!
//    @IBOutlet weak var loginButton: UIButton!
//    @IBOutlet weak var accountMessageLabel: UILabel!
//
    
    
    @IBOutlet var contentsView: UIView!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var logButton: UIButton!
    @IBOutlet weak var accontMsgLabel: UILabel!
    
    private var tapGesture: UITapGestureRecognizer!
    

    private var accountLoginState = AccountLoginState.newAccount
    
    public weak var delegate: LoginViewDelegate?
    
    
    override init(frame: CGRect) {
        super.init(frame: UIScreen.main.bounds)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    

    private func commonInit() {

        Bundle.main.loadNibNamed("LoginView", owner: self, options: nil)
        addSubview(contentsView)
        contentsView.frame = bounds
        contentsView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        logButton.addTarget(self, action: #selector(loginButtonPressed), for: .touchUpInside)
        accontMsgLabel.isUserInteractionEnabled = true
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gestureRecognizer:)))
        accontMsgLabel.addGestureRecognizer(tapGesture)
    }
    
    @objc private func loginButtonPressed() {
        delegate?.didSelectLoginButton(self, accountLoginState: accountLoginState)
    }
    
    @objc private func handleTap(gestureRecognizer: UITapGestureRecognizer) {
        accountLoginState = accountLoginState == .newAccount ? .existingAccount : .newAccount
        switch accountLoginState {
        case .newAccount:
            logButton.setTitle("Create", for: .normal)
            accontMsgLabel.text = "Login into your account"
        case .existingAccount:
            logButton.setTitle("Login", for: .normal)
            accontMsgLabel.text = "New User? Create an account"
        }
    }
}
